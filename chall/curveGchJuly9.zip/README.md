# Challenge: Log File Processor

Copyright 2018 Curve Dental

Contents:
    * This README file.
    * "remoteobjects" directory containing contents of two buckets, 'archivedlogs' and 'logs'
    * "inventory.csv" file containing the inventory of all objects

The problem to solve is detailed in the email which accompanied this package.

Your script solution should be committed on a separate git branch in this repository.
Submit it as a single zip archive of the complete repository including the .git directory.
Do not include any processed logs - as we should be able to reproduce those with your solution!
